<?php

XTS\Modules\Patcher\Client::get_instance()->render();
